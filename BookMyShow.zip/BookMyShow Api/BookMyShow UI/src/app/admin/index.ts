export * from './addmovie/addmovie.component'
export * from './addtimeslots/addtimeslots.component'
export * from './admin.component'
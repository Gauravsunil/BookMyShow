export class LoginResponse {

token:any;
expiration:any;
user:any;
id:any;
status:any;
message:any;
role:any;
}

export class Response{
status:any;
message:any;
}

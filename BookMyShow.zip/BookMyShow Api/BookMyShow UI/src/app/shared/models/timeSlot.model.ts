export class TimeSlot{

    id:any;
    startTime:any;
    endTime:any;
}
export class Booking {
    userId:any;
    movieId:any;
    quantity:any;
    constructor (userId:any,movieId:any,quantity:any){
        this.userId=userId;
        this.movieId=movieId;
        this.quantity=quantity;
    }
}

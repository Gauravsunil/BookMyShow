import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confirmed-booking',
  templateUrl: './confirmed-booking.component.html'
})
export class ConfirmedBookingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
